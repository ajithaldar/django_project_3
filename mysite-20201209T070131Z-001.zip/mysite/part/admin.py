from django.contrib import admin

# Register your models here.
from .models import Post,PostImage,mes_info,Categorie,Chapter
# Register your models here.
admin.site.register(mes_info)
admin.site.register(Categorie)
admin.site.register(Chapter)
class PostImageAdmin(admin.StackedInline):
    model = PostImage
 
@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    inlines = [PostImageAdmin]
 
    class Meta:
       model = Post
 
@admin.register(PostImage)
class PostImageAdmin(admin.ModelAdmin):
    pass