from django.apps import AppConfig


class PartConfig(AppConfig):
    name = 'part'
