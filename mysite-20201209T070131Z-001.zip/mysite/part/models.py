from django.db import models


# Create your models here.
class Categorie(models.Model):
	title = models.CharField(max_length=200)
	def __str__(self):
		return self.title
class Post(models.Model):
    title = models.CharField(max_length=250)
    typ=models.CharField(max_length=250)
    description = models.TextField()
    image = models.FileField(blank=True)
    categorie=models.ManyToManyField(Categorie)
 
    def __str__(self):
        return self.title


class PostImage(models.Model):
    post = models.ForeignKey(Post, default=None, on_delete=models.CASCADE)
    images = models.FileField(upload_to = 'images/')
 
    def __str__(self):
        return self.post.__str__()

class mes_info(models.Model):
	un=models.CharField(max_length=100)
	id=models.AutoField(primary_key=True)
	message=models.TextField()
	
class Chapter(models.Model):
    title = models.CharField(max_length=250)
    description = models.TextField()
     
    def __str__(self):
        return self.title