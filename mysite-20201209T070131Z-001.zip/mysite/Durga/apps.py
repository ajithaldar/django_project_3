from django.apps import AppConfig


class DurgaConfig(AppConfig):
    name = 'Durga'
